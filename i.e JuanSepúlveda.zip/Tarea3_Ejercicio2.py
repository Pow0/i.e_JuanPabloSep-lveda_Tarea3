# -*- coding: utf-8 -*-

"""
N1 = Cantidad de notas
Calculo = variable que cuenta las notas sumadas
Res = resultado
"""
print ("Calculadora de promedio de notas")
print ("Numero de notas que desea promediar:  ")

N = int(input())
while N <=0:
    print ("La cantidad de notas no puede ser menor o igual a 0")
    print ("Intente denuevo: ")
    N = int(input())
    
Calculo = 1

Sumas = 0

#Compara la cantidad de notas sumadas con el conteo de notas
while Calculo <= N:
    print ("indique su nota numero ",Calculo,":")
    Sumas = (Sumas + float(input())) #reescribe la variable y suma la siguiente nota
    Calculo = Calculo + 1            # suma +1 al conteo de notas sumadas
    
Res = float(Sumas/N)                 # Calcula el promedio de las notas

print ("Tu promedio es ", Res)

# Da el caso resultante según el promedio

if Res >=4.0:
    print ("Felicitaciones, vas camino a aprobar.")
    
elif Res >= 3.0 and Res <4.0:
    print ("Atención, vas camino a reprobar.")
    
elif Res < 3.0:
    print ("Pocas posibilidades de aprobar")