#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Fri Apr  7 22:33:55 2023

@author: Pow0

Tarea 3 ejercicio 2
"""

print ("división entre 2 números")
print ("Seleccione un numero cualquiera A (dividendo):  ")
A = float(input ())
print ("Seleccione un numero cualquiera B (divisor):  ")
B = float(input ())

while B == 0: 
    print("Ese valor para B no existe para una división")
    print("intente con otro valor:")
    B = int(input())
    
C = A/B       # C es el resultado de la división.
D = A//B      # D es el resultado entero de la división.

resto = C-D   # Al restar C-D se calcula el resto de la división

if resto != 0:      # Si el resto es distinto a 0 la division no es exacta.
    print ("“A” no divide a “B” de forma exacta.")
    print ("Y el resultado es", C)
else:               # Si el resto es 0, la división es exacta.
    print ("“A” divide exactamente a “B”.")
    print ("Y el resultado es", C)