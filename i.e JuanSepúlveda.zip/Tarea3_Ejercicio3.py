#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 20 20:19:21 2023

@author: Pow0
"""


#------------------------------------------------------------------------------
# Variables principales + lista de días en cada mes + febrero se define más adelante
#------------------------------------------------------------------------------


print("Indique una fecha cualquiera ")
print("  ")
print("Se comprobará:")
print("Si la fecha es año bisiesto")
print("La cantidad de días pasados desde el inicio del año")
print("La cantidad de días restantes para el natalicio de Isaac Newton")
print("extra: días desde que nació Isaac Newton")
print(" ")
print("Indique el dia de la fecha")
Dia = int(input())
print("Indique el mes de la fecha")
Mes = int(input())
print("Indique el año de la fecha")
Anio = int(input())

DiasMes = [31,28,31,30,31,30,31,31,30,31,30,31] # está lista solo se usa en:
                                                # Suma de los días de los meses


#------------------------------------------------------------------------------
# Calcula año bisiesto
#------------------------------------------------------------------------------


bi = 0

if Anio % 4 == 0 and Anio % 100 != 0 and Anio % 400 != 0 :
    bi = 1
    DiasMes [1] = 29
if Anio % 100 == 0 and Anio % 400 == 0 and Anio %4 == 0:
    bi = 1
    DiasMes [1] = 29


#------------------------------------------------------------------------------
# Ciclo para compróbara validez de la fecha
#------------------------------------------------------------------------------


M=0 # cantidad de días del mes seleccionado
while M == 0:
    
    if Mes in [1,3,5,7,8,10,12]:  # meses con 31 días
        M = 31                    # cantidad de días
        while Dia <1 or Dia >31:  # comprueba si el dia corresponde
            print("el dia ingresado no corresponde con el mes")
            print("Ingrese otro valor de dia.")
            Dia = int(input())    # redefine el dia
            
    if Mes in [4,6,9,11]:         # meses con 30 dias
        M = 30
        while Dia <1 or Dia >30: 
            print("el dia ingresado no corresponde con el mes")
            print("Ingrese otro valor de dia.")
            Dia = int(input())
            
    if Mes ==2:                   #dias de febrero
        if bi == 0:
            M = 28
            while Dia <1 or Dia >28:
                print("el dia ingresado no corresponde con el mes")
                print("Ingrese otro valor de dia.")
                Dia = int(input())
                
        if bi == 1:
            M = 29
            while Dia <1 or Dia >29:    # comprueba si el dia corresponde
                print("el dia ingresado no corresponde con el mes")
                print("Ingrese otro valor de dia.")
                Dia = int(input())
                
    if Mes <1 or Mes >12:
        print("el mes no puede ser mayor de 12 o menor de 1, ya que no existen otros meses")
        print("Indíquelo otra vez:")
        Mes = int(input())

        
#------------------------------------------------------------------------------
# Suma de los días de los meses
#------------------------------------------------------------------------------


s= Mes -2 # -1 para que cuadre con la posicion y otro -1 para tomar en cuenta
          # el mes anterior
          # s es usado para el ciclo
DiasMesSum = 0 # es la cantidad de días del año que pertenecen a los meses cómpletos

while s >=0:
    DiasMesSum = DiasMesSum + DiasMes[s]
    s = s-1    


#------------------------------------------------------------------------------
# calcula la cantidad de días transcurridos desde el inicio del año
#------------------------------------------------------------------------------


DiasTranscurridos = DiasMesSum + Dia


#------------------------------------------------------------------------------
# calcula la cantidad de días que faltan para el natalício del Isaac Newtom
#------------------------------------------------------------------------------


cant = 365 + bi # cant = días del año
isaac= 0   # cumple de mi amigo Isaac

if DiasTranscurridos <=4:
    isaac = (4-DiasTranscurridos)
if DiasTranscurridos >4:
    isaac = cant + 4 - DiasTranscurridos 
    
    
#------------------------------------------------------------------------------
# calcula la cantidad de días que han pasado desde el nacimiento de Isaac Newtom
#------------------------------------------------------------------------------
# Estó no va en la evaluación, pero pense que se calculaba sú cumpleaños y 
# me esforze mucho por esto, así que lo incluí igual :)

EXTRA = (Anio*365) + (Anio//4) + DiasTranscurridos - 600109
#(días según el año) + (bisiestos) + (días del año seleccionado) - valor en días del cumpleaños de I Newton

#------------------------------------------------------------------------------
# Resultados
#------------------------------------------------------------------------------


print (" ")
print("han pasado ", DiasTranscurridos, "dias desde el inicio del año.")
print (" ")
if bi == 0:
    print("el año indicado no es bisiesto.")
if bi == 1:
    print("el año indicado es bisiesto")
print (" ")
print("Y faltan ",isaac," dias para el natalicio de Isaac Newton")
print ( )
if EXTRA > 0:
    print ("Extra: Hace ",EXTRA," dias fue el nacimiento de Isaac Newton")
if EXTRA < 0 :
    print ("Extra: Isaac Newton aún no nace")


